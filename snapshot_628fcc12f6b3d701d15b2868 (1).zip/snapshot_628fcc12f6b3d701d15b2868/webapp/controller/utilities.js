sap.ui.define([
	"./utilities"
], function() {
	"use strict";

	// class providing static utility methods to retrieve entity default values.

	return {
		getDefaultValuesForDetailPage1: function() {
			return {
				"ID": "id-" + Date.now().toString(),
				"Name": "",
				"CustomerName": "",
				"POCategory": "",
				"GrossAmount": 0,
				"CurrencyCode": "",
				"Tax": 0,
				"DeliveryStatusDescription": "",
				"LifecycleStatusDescription": "",
				"NOLineItems": 0,
				"NOOpenItems": 0,
				"CreatedAt": "",
				"RequestedDate": "",
				"___FK_0e6d9d20b26172910ae03cdb": "",
				"NOShippedItems": 0,
				"NoOpenItems2": 0,
				"NoShippedItems2": 0,
				"DeliveryStatusType": "",
				"NOInProcessItems": "",
				"___FK_aa90c5af7f24d7691751b7b7_00004": ""
			};
		},
		getDefaultValuesForDetailPage3: function() {
			return {
				"ID": "id-" + Date.now().toString(),
				"Quantity": 0,
				"QuantityUnit": "",
				"RequestedDelivery": "",
				"EstimatedDelivery": "",
				"GrossAmount": 0,
				"Currency": "",
				"___FK_e5ec6d25f58706080ae03cdb": "",
				"___FK_41df27d78bc37fc30ae03cdb": "",
				"LineItemNO": "",
				"ShippedQuantity": 0,
				"StatusSummary": "",
				"___FK_51c46ebd7590ee4a0ae16730": "",
				"ShippedDate": ""
			};
		}
	};
});
